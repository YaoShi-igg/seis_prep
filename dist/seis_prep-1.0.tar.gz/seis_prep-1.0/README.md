# seis_prep
Some functions for process seismic data
