# some preprocess scripts for event data and noise data 
# 2024.05.28, Shi Yao

__version__ = "1.0"  
__author__="Shi Yao",
__author_email__="yaoshi229@gmail.com"
